"use strict";
exports.__esModule = true;
exports.EmailTypes = void 0;
var EmailTypes;
(function (EmailTypes) {
    EmailTypes[EmailTypes["Activation"] = 0] = "Activation";
    EmailTypes[EmailTypes["RedefinePassword"] = 1] = "RedefinePassword";
})(EmailTypes = exports.EmailTypes || (exports.EmailTypes = {}));
