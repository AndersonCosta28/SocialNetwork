"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
exports.__esModule = true;
exports.CustomErrorAPI = void 0;
var status_code_enum_1 = require("status-code-enum");
var __1 = require("..");
var CustomErrorAPI = /** @class */ (function (_super) {
    __extends(CustomErrorAPI, _super);
    function CustomErrorAPI(error, code) {
        if (code === void 0) { code = status_code_enum_1.StatusCode.ClientErrorBadRequest; }
        var _this = this;
        var _a;
        _this = _super.call(this) || this;
        Object.setPrototypeOf(_this, CustomErrorAPI.prototype);
        _this.stack = "";
        _this.name = "CustomErrorAPI";
        _this.message = (_a = (0, __1.getErrorMessage)(error)) !== null && _a !== void 0 ? _a : "uncataloged error";
        _this.statusCode = code;
        if (error instanceof CustomErrorAPI)
            _this.statusCode = error.statusCode;
        else if (error instanceof Error)
            _this.stack = error.stack;
        else
            console.log(error);
        return _this;
    }
    CustomErrorAPI.throwError = function (error) {
        if (error instanceof CustomErrorAPI)
            return error;
        else
            return new CustomErrorAPI(error);
    };
    return CustomErrorAPI;
}(Error));
exports.CustomErrorAPI = CustomErrorAPI;
