"use strict";
exports.__esModule = true;
exports.UserStates = void 0;
var UserStates;
(function (UserStates) {
    UserStates["WaitingForActivation"] = "Waiting for activation";
    UserStates["Active"] = "Active";
    UserStates["Blocked"] = "Blocked";
    UserStates["Banned"] = "Banned";
})(UserStates = exports.UserStates || (exports.UserStates = {}));
