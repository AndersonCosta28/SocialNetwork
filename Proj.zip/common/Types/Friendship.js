"use strict";
exports.__esModule = true;
exports.TypesOfApplicants = exports.TypeOfFriendship = void 0;
var TypeOfFriendship;
(function (TypeOfFriendship) {
    TypeOfFriendship[TypeOfFriendship["Requested"] = 0] = "Requested";
    TypeOfFriendship[TypeOfFriendship["Friend"] = 1] = "Friend";
    TypeOfFriendship[TypeOfFriendship["Blocked"] = 2] = "Blocked";
    TypeOfFriendship[TypeOfFriendship["Removed"] = 3] = "Removed";
})(TypeOfFriendship = exports.TypeOfFriendship || (exports.TypeOfFriendship = {}));
var TypesOfApplicants;
(function (TypesOfApplicants) {
    TypesOfApplicants[TypesOfApplicants["Me"] = 0] = "Me";
    TypesOfApplicants[TypesOfApplicants["Other"] = 1] = "Other";
})(TypesOfApplicants = exports.TypesOfApplicants || (exports.TypesOfApplicants = {}));
