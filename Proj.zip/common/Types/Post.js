"use strict";
exports.__esModule = true;
exports.TypePostReactions = void 0;
var TypePostReactions;
(function (TypePostReactions) {
    TypePostReactions[TypePostReactions["Like"] = 0] = "Like";
})(TypePostReactions = exports.TypePostReactions || (exports.TypePostReactions = {}));
