import { StatusCode } from "status-code-enum";
export declare class CustomErrorAPI extends Error {
    message: string;
    statusCode: StatusCode;
    constructor(error: unknown, code?: StatusCode);
    static throwError(error: unknown): CustomErrorAPI;
}
