import { IProfile } from "./User";
export declare enum TypeOfFriendship {
    "Requested" = 0,
    "Friend" = 1,
    "Blocked" = 2,
    "Removed" = 3
}
export declare enum TypesOfApplicants {
    Me = 0,
    Other = 1
}
export interface ICreateBodyRequest {
    SourceId: number;
    TargetName: string;
}
export interface IFindAllByUserBodyRequest {
    UserId: number;
}
export type IReactToFriendRequestBodyRequest = {
    UserId: number;
    FriendshipId: number;
    React: boolean;
};
export interface IMessage {
    FriendshipId: number;
    FromId: number;
    ToId: number;
    Message: string;
    id: number;
}
export interface IFriend {
    FriendshipId: number;
    FriendProfile: IProfile;
    Type: TypeOfFriendship | string;
    WhoRequested: TypesOfApplicants;
}
