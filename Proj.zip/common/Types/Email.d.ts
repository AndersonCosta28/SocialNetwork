export declare enum EmailTypes {
    "Activation" = 0,
    "RedefinePassword" = 1
}
export interface IAddress {
    name: string;
    email: string;
}
export interface IEmailMessage {
    to: IAddress;
    from: IAddress;
    subject: string;
    text: string;
    html: string;
}
