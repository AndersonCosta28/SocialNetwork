"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
exports.__esModule = true;
exports.regexPassword = exports.getAxiosErrorMessage = exports.getErrorMessage = exports.addHours = void 0;
__exportStar(require("./Types/Friendship"), exports);
__exportStar(require("./Types/Response"), exports);
__exportStar(require("./Types/User"), exports);
__exportStar(require("./Types/Email"), exports);
__exportStar(require("./Types/CustomErrors"), exports);
__exportStar(require("./Types/Post"), exports);
var addHours = function (date, hours) {
    var copiedDate = new Date(date.getTime());
    copiedDate.setHours(copiedDate.getHours() + hours);
    return copiedDate;
};
exports.addHours = addHours;
var getErrorMessage = function (error) {
    return error instanceof Error ? error.message : error;
};
exports.getErrorMessage = getErrorMessage;
var getAxiosErrorMessage = function (error) {
    var _a;
    if (error.hasOwnProperty("response"))
        return (_a = error.response.data.message) !== null && _a !== void 0 ? _a : error.response.data;
    else
        return error instanceof Error ? error.message : error;
};
exports.getAxiosErrorMessage = getAxiosErrorMessage;
exports.regexPassword = /[\w\d\s]{8,}/;
